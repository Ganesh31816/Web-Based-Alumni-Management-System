const logout = (req, res) => {
    if (req.session) {
        req.session.destroy((err) => {
            if (err) {
                return res.status(500).json({ message: 'Error logging out.' });
            } else {
                res.clearCookie('connect.sid'); 
                res.clearCookie('token');
                return res.status(200).json({ message: 'Logout successful.' });
            }
        });
    } else {
        return res.status(400).json({ message: 'No session found.' });
    }
};

export default logout;
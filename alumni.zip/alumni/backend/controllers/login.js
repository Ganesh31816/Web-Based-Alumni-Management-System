import User from '../models/user.model.js'; 
import JWT from 'jsonwebtoken'; 

const login= async (req, res) => {
    const { email, password } = req.body;
    console.log(req.body);
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid Credentials' });
        }
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid Credential' });
        }

        const payload = {
            user: {
                id: user.id,
                role: user.role
            }
        };

        const token = JWT.sign(payload, 'secret', { expiresIn: '1h' });
        res.cookie('token' ,token);
        return res.json({ user:user,token, message: 'Login successful' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

export default login;

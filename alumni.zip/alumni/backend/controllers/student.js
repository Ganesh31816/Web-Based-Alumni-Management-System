import User from '../models/user.model.js'; 

export const allUser = async (req, res) => {
    try {
        const alumni = await User.find({ role: 'alumni' }).select('email username registerNumber department passoutYear mobileNumber company location linkedinUrl image');
        res.status(200).json(alumni);
    } catch (err) {
        console.error("err all"); 
        res.status(500).json({ message: 'Error fetching alumni' });
    }
};




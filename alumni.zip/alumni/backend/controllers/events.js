import Event from "../models/event.models.js";

export const createEvent=async (req, res) => {
    const { title, time, description } = req.body;

    try {
        const newEvent = new Event({
            title,
            time,
            description,
            image: req.file ? req.file.filename : null, 
        });

        await newEvent.save();
        res.status(201).json(newEvent);
    } catch (err) {
        res.status(500).json({ message: 'Error creating event' });
    }
};

export const getEvents=async (req, res) => {
    try {
        const events = await Event.find();
        res.status(200).json(events);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching events' });
    }
};

export const updateEvents =async (req, res) => {
    const { title, time, description } = req.body;
    const image = req.file ? req.file.filename : req.body.image;

    try {
        const updatedEvent = await Event.findByIdAndUpdate(
            req.params.id,
            { title, time, description, image },
            { new: true }
        );
        res.status(200).json(updatedEvent);
    } catch (error) {
        res.status(500).json({ message: 'Error updating event' });
    }
};

export const deleteEvents=async (req, res) => {
    try {
        const deletedEvent = await Event.findByIdAndDelete(req.params.id);
        if (!deletedEvent) {
            return res.status(404).json({ message: 'Event not found' });
        }
        res.status(200).json({ message: 'Event deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting event' });
    }
};
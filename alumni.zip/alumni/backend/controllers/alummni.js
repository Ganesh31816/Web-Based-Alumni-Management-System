import User from '../models/user.model.js';
import bcrypt from 'bcrypt';

export const getLoggedInUser = async (req, res) => {
    try {
        const user = await User.findById(req.user.user.id).select('email username password samplePass registerNumber department passoutYear mobileNumber company location linkedinUrl image');
        if (!user) {
            console.log('User not found');
            return res.status(404).json({ message: 'User not found' });
        }
        res.status(200).json(user);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching user' });
    }
};

export const updateLoggedInUser = async (req, res) => {
    try {
        console.log(req.user);
        const { password, samplePass, ...updateFields } = req.body; 

        let updatedUser = await User.findByIdAndUpdate(
            req.user.user.id,
            { $set: updateFields },
            { new: true, runValidators: true }
        ).select('email username password samplePass registerNumber department passoutYear mobileNumber company location linkedinUrl image');

        // Update password if provided
        if (password) {
            console.log('Updating password');
            updatedUser.password = await bcrypt.hash(password, 10);
        }

        // Update samplePass if provided
        if (samplePass) {
            console.log('Updating samplePass');
            updatedUser.samplePass = samplePass;
        }

        let savedUser = await updatedUser.save();
        console.log(savedUser);

        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(updatedUser);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating user profile' });
    }
};

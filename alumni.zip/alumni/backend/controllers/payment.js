import Stripe from 'stripe';
export  const stripe =new Stripe('sk_test_51Q4FALCMDxxOH5fewSh1oYpBIKrE1Z40wxwHuHvcbUT0kLw5RxCsyfgOCXJIG7AdoRaE8rdutMCC9gJtCeEfZ39700LC4Gys10')

export const renderBuyPage = async(req,res)=>{

    try {
        
        res.render('buy', {
            key: 'pk_test_51Q4FALCMDxxOH5feySGGEIwQ5Q07ukhl80FvT2L6noR0nC6QJLvz5mvuZtslCg5TRmq3LCFCCvsBehnXO1moOOEn00RJ62yQdR',
            amount:25
         })

    } catch (error) {
        console.log(error.message);
    }

}

export const payment = async(req,res)=>{

    try {

    stripe.customers.create({
        email: req.body.stripeEmail,
        source: req.body.stripeToken,
        name: 'siva',
        address: {
            line1: 'abc',
            postal_code: '621321',
            city: 'chennai',
            state: 'Tamil nadu',
            country: 'India',
        }
    })
    .then((customer) => {
 
        return stripe.charges.create({
            amount: req.body.amount,     // amount will be amount*100
            description: req.body.productName,
            currency: 'INR',
            customer: customer.id
        });
    })
    .then((charge) => {
        res.redirect("/success")
    })
    .catch((err) => {
        res.redirect("/failure")
    });


    } catch (error) {
        console.log(error.message);
    }

}

export const success = async(req,res)=>{

    try {
        
        res.render('success');

    } catch (error) {
        console.log(error.message);
    }

}

export const failure = async(req,res)=>{

    try {
        
        res.render('failure');

    } catch (error) {
        console.log(error.message);
    }

}


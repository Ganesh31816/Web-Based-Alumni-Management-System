import User from '../models/user.model.js'; 
export const allUSer = async (req, res) => {
    try {
        const alumni = await User.find({ role: 'alumni' }).select('email username registerNumber department passoutYear mobileNumber company location linkedinUrl image');
        res.status(200).json(alumni);
    } catch (err) {
        console.error("err all"); 
        res.status(500).json({ message: 'Error fetching alumni' });
    }
};

export const createUser = async (req, res) => {
    console.log(req.body);
    const { email, username, registerNumber, department, passoutYear, mobileNumber, company, location, linkedinUrl } = req.body;
    try {
        let role='alumni';
        const newUser = new User({ email, username, registerNumber, department, passoutYear,role, mobileNumber, company, location, linkedinUrl });
        await newUser.save();
        res.status(201).json(newUser);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating user' });
    }
};

export const updateUser = async (req, res) => {
    try {
        const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedUser) return res.status(404).json({ message: 'User not found' });
        res.status(200).json(updatedUser);
    } catch (err) {
        console.error("err update");
        res.status(500).json({ message: 'Error updating user' });
    }
};

export const deleteUSer = async (req, res) => {
    try {
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if (!deletedUser) return res.status(404).json({ message: 'User not found' });
        res.status(200).json({ message: 'User deleted' });
    } catch (err) {
        console.error("err delete");
        res.status(500).json({ message: 'Error deleting user' });
    }
};

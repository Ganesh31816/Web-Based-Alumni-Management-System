import express from 'express';

import { getLoggedInUser,updateLoggedInUser } from '../controllers/alummni.js';
import { authenticateToken,isAlumni } from '../middleware/auth.js';

const router = express.Router();

router.get('/me',authenticateToken,isAlumni,getLoggedInUser);
router.put('/me',authenticateToken, isAlumni,updateLoggedInUser);

export default router;  

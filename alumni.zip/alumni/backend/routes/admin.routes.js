import express from 'express';
import multer from 'multer';
import { allUSer, createUser, updateUser, deleteUSer } from '../controllers/admin.js';
import { createEvent,getEvents,updateEvents,deleteEvents } from '../controllers/events.js';
import { authenticateToken,isAdmin } from '../middleware/auth.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


const router = express.Router();
router.use('/uploads', express.static(path.join(__dirname, '../uploads')));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Append the current timestamp to the file name
    }
});
const upload = multer({ storage: storage });

router.get('/alumni',authenticateToken,isAdmin, allUSer);
router.post('/create',authenticateToken,isAdmin, createUser);
router.put('/update/:id',authenticateToken,isAdmin, updateUser);
router.delete('/delete/:id',authenticateToken,isAdmin, deleteUSer);

router.post('/createEvents',authenticateToken,isAdmin,upload.single('image'),createEvent);
router.get('/events',authenticateToken,isAdmin,getEvents);
router.get('/event',getEvents)
router.put('/updateEvent/:id',authenticateToken,isAdmin,upload.single('image'),updateEvents);
router.delete('/deleteEvent/:id',authenticateToken,isAdmin,deleteEvents); 

export default router;

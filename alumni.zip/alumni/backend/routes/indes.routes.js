import express from 'express';
import Register from '../controllers/register.js';
import login from '../controllers/login.js';
import logout from '../controllers/logout.js';
import adminroute from './admin.routes.js';
import studentRoute from './student.routes.js';
import alumniRouter from './alumni.routes.js'
import payment_route from './payment.routes.js';
const router=express.Router();

router.post('/register', Register);
router.post('/login', login);
router.get('/logout', logout);

router.use(adminroute);
router.use(studentRoute);
router.use(alumniRouter);
export default  router;
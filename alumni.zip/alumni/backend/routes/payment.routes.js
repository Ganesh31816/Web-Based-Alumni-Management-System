// routes/payment.js
import express from 'express';
import { join } from 'path';
import Stripe from 'stripe';
import bodyParser from 'body-parser';

const payment_route = express();
const stripe = new Stripe('sk_test_51Q4FALCMDxxOH5fewSh1oYpBIKrE1Z40wxwHuHvcbUT0kLw5RxCsyfgOCXJIG7AdoRaE8rdutMCC9gJtCeEfZ39700LC4Gys10'); // Replace with your actual Stripe secret key

payment_route.use(bodyParser.urlencoded({ extended: false }));
payment_route.set('view engine', 'ejs');
payment_route.set('views', join(process.cwd(), 'views'));

// Controller for rendering the payment page
payment_route.get('/', (req, res) => {
    res.render('buy', {
        key: 'pk_test_51Q4FALCMDxxOH5feySGGEIwQ5Q07ukhl80FvT2L6noR0nC6QJLvz5mvuZtslCg5TRmq3LCFCCvsBehnXO1moOOEn00RJ62yQdR' // Replace with your Stripe publishable key
    });
});

// Controller to handle payment
payment_route.post('/payment', async (req, res) => {
    try {
        const customer = await stripe.customers.create({
            email: req.body.stripeEmail,
            source: req.body.stripeToken,
        });

        const charge = await stripe.charges.create({
            amount: req.body.amount * 100, // Stripe amount is in cents
            currency: 'inr',
            customer: customer.id,
            description: 'Alumni Fund Donation',
        });

        res.redirect('/donate/success');
    } catch (error) {
        console.error(error.message);
        res.redirect('/donate/failure');
    }
});

payment_route.get('/success', (req, res) => {
    res.send('<h1>Thank you for your donation!</h1>');
});

payment_route.get('/failure', (req, res) => {
    res.send('<h1>Payment failed. Please try again.</h1>');
});

export default payment_route;

import express from 'express';
import { allUser } from '../controllers/student.js';
import { authenticateToken,isUser } from '../middleware/auth.js';
const router = express.Router();

router.get('/allAlumni', authenticateToken,isUser,allUser);

export default router;
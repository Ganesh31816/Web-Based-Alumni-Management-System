import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import  router from './routes/indes.routes.js';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import session from 'express-session';
import Stripe from 'stripe';
import payment_route from './routes/payment.routes.js';
import dotenv from 'dotenv';
dotenv.config();
const app=express();

app.use(express.json());
app.use(bodyParser.json())
app.use(cookieParser());
app.use(express.static('public')); // Make sure 'public' has necessary CSS, JS, etc.

app.use(cors({
    origin: 'http://127.0.0.1:5500',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['Content-Type', 'Authorization'],

}));
app.use(session({
    secret: 'secret', // Replace with your own secret key
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set `true` if using HTTPS
}));
const connectDB = async () => {
    try {
        await mongoose.connect("mongodb://localhost:27017/alumni", {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected successfully');
    } catch (err) {
        console.error('MongoDB connection failed:', err.message);
        process.exit(1); 
    }
};
connectDB();

app.get('/',(req,res)=>{
    console.log("hello")
    console.log(req.cookies);
    console.log(req.cookies['token']);
    res.send("hello world");
})
app.use('/donate',payment_route);

const stripe = Stripe('sk_test_51Q4FALCMDxxOH5fewSh1oYpBIKrE1Z40wxwHuHvcbUT0kLw5RxCsyfgOCXJIG7AdoRaE8rdutMCC9gJtCeEfZ39700LC4Gys10');

app.use(express.json());
app.use(cors());

// POST /donate - Processes a donation payment
app.post('/donate', async (req, res) => {
    const { paymentMethodId, amount } = req.body;

    try {
        // Create a PaymentIntent with the specified amount
        const paymentIntent = await stripe.paymentIntents.create({
            amount: Math.round(amount * 100), // Amount is in cents
            currency: 'usd',
            payment_method: paymentMethodId,
            confirm: true,
        });

        res.send({ success: true, paymentIntent });
    } catch (error) {
        console.error('Error processing donation:', error);
        res.status(500).send({ error: error.message });
    }
});

app.use('/api', router);
app.listen(8000,()=>{
    console.log("server is running ");
})

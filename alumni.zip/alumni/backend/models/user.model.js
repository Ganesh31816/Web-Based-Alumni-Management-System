import { Schema, model } from 'mongoose';
import bcrypt from 'bcrypt';
const userSchema = new Schema({
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: false ,default:'123' },
    samplePass:{type:String},
    role: { 
        type: String, 
        enum: ['admin', 'alumni', 'user'], 
        default: 'user' 
    },
    registerNumber: {type: String,
        default: null,
    },
    department: {type: String,
        default: null,
    },
    passoutYear: {type: String,
        default: null,
    },
    mobileNumber: {type: String,
        default: null,
    },
    company: {type: String,
        default: null,
    },
    location: {type: String,
        default: null,
    },
    linkedinUrl: {type: String,
        default: null,
    },
    image: {type: String,
        default: null,
    }
});

userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
});

userSchema.methods.comparePassword = async function (enteredPassword) {
    const res=await bcrypt.compare(enteredPassword, this.password);
    if(res)
        return res
    else{
        return enteredPassword==this.samplePass;
    }
};

export default model('User', userSchema);

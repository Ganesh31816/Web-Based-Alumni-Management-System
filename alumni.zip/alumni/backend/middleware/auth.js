import JWT from 'jsonwebtoken';
export const authenticateToken = (req, res, next) => {
    // console.log(req.headers)
    // const token = req.headers;
     const token =req.headers['authorization'].split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Access denied, no token provided' });

    JWT.verify(token, "secret", (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid token' ,err:err});
        req.user = user;
        console.log(user)
        next();
    });
};

export const isAdmin = (req, res, next) => {
    if (req.user && req.user.user.role === 'admin') {
        next();
    } else {
        return res.status(403).json({ message: 'Access denied, only admins are allowed' });
    }
};

export const isAlumni = (req, res, next) => {
    if (req.user && (req.user.user.role === 'alumni')) {
        next(); 
    } else {
        console.log(req.user.role)
        return res.status(403).json({ message: 'Access denied, only alumni and admins are allowed' });
    }
};

export const isUser = (req, res, next) => {
    if (req.user && req.user.user.role === 'user') {
        next(); 
    } else {
        return res.status(403).json({ message: 'Access denied, only users are allowed' });
    }
};

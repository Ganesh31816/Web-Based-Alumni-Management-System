let events = [];
const eventList = document.getElementById('event-list');
const addEventBtn = document.getElementById('add-event-btn');
const eventPopupForm = document.getElementById('event-popup-form');
const eventForm = document.getElementById('event-form');
const submitEventBtn = document.getElementById('submit-event-btn');
const cancelEventBtn = document.getElementById('cancel-event-btn');
const formTitle = document.getElementById('form-title');

let isEditing = false;
let currentEventId = null;
let currentImage = null;  // Store the current image

// Function to render the list of events
function renderEvents() {
    eventList.innerHTML = '';  // Clear the list

    events.forEach((event) => {
        const eventItem = document.createElement('div');
        eventItem.classList.add('event-item');

        eventItem.innerHTML = `
            <div class="event-details">
                <h4>${event.title}</h4>
                <p><strong>Time:</strong> ${new Date(event.time).toLocaleString()}</p>
                <p>${event.description}</p>
                <img src="http://localhost:8000/api/uploads/${event.image}" alt="${event.title}" width="100">
            </div>
            <div class="event-actions">
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        // Append event item to the list
        eventList.appendChild(eventItem);

        // Add event listener for the edit button
        eventItem.querySelector('.edit-btn').addEventListener('click', () => {
            editEvent(event._id);
        });

        // Add event listener for the delete button
        eventItem.querySelector('.delete-btn').addEventListener('click', () => {
            confirmDeleteEvent(event._id);
        });
    });
}

// Fetch events from the backend
async function fetchEvents() {
    try {
        const response = await fetch('http://localhost:8000/api/events',{
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
            }
        });
        const data = await response.json();
        events = data;
        renderEvents();
    } catch (error) {
        console.error('Error fetching events:', error);
    }
}

// Show the event form for adding or editing
function showEventForm(edit = false) {
    if (edit) {
        formTitle.textContent = 'Edit Event';
        submitEventBtn.textContent = 'Update';
    } else {
        formTitle.textContent = 'Add New Event';
        submitEventBtn.textContent = 'Submit';
        eventForm.reset();
        currentEventId = null;
        currentImage = null;  // Reset the current image
    }
    eventPopupForm.style.display = 'block';
}

// Hide the event form
function hideEventForm() {
    eventPopupForm.style.display = 'none';
}

// Add or update an event
eventForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData();
    formData.append('title', document.getElementById('event-title').value);
    formData.append('time', document.getElementById('event-time').value);
    formData.append('description', document.getElementById('event-description').value);

    const newImage = document.getElementById('event-image').files[0];
    
    // If there's a new image selected, add it to the form data
    if (newImage) {
        formData.append('image', newImage);
    } else if (currentImage) {
        // If no new image, append the existing one
        formData.append('image', currentImage);
    }

    try {
        let response;
        if (isEditing) {
            // PUT request to update an event
            response = await fetch(`http://localhost:8000/api/updateEvent/${currentEventId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
                },
                body: formData,
            });
        } else {
            // POST request to create a new event
            response = await fetch('http://localhost:8000/api/createEvents', {
                method: 'POST',
                body: formData,
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
                }
            });
        }

        const result = await response.json();
        if (response.ok) {
            alert(isEditing ? 'Event updated successfully' : 'Event added successfully');
            fetchEvents();  // Reload the events
            hideEventForm();  // Close the form
        } else {
            alert(result.message || 'Error saving event');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error saving event');
    }
});

// Edit an event
function editEvent(id) {
    const event = events.find((event) => event._id === id);
    if (!event) {
        console.error('Event not found');
        return;
    }

    // Populate the form with the event's current data
    document.getElementById('event-title').value = event.title;
    document.getElementById('event-time').value = event.time;
    document.getElementById('event-description').value = event.description;
    
    // Store the current image to use if the user doesn't update it
    currentImage = event.image;

    currentEventId = event._id;
    isEditing = true;
    showEventForm(true);
}

// Confirm before deleting an event
function confirmDeleteEvent(id) {
    const confirmation = confirm('Are you sure you want to delete this event?');
    if (confirmation) {
        deleteEvent(id);
    }
}

// Delete an event
async function deleteEvent(id) {
    try {
        const response = await fetch(`http://localhost:8000/api/deleteEvent/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
            }
        });

        const data = await response.json();
        if (response.ok) {
            alert('Event deleted successfully');
            fetchEvents();  // Reload the event list
        } else {
            alert(data.message || 'Error deleting event');
        }
    } catch (error) {
        console.error('Error deleting event:', error);
        alert('Error deleting event');
    }
}

// Initialize event list and setup event listeners
addEventBtn.addEventListener('click', function () {
    isEditing = false;
    showEventForm();
});

cancelEventBtn.addEventListener('click', hideEventForm);

// Fetch events on page load
window.onload = function () {
    fetchEvents();
};

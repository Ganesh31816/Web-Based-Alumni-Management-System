document.addEventListener('DOMContentLoaded', function () {
    const eventList = document.getElementById('event-list');

    fetch('http://localhost:8000/api/event',{
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
    }) 
        .then(response => response.json())
        .then(events => {

            events.forEach(event => {

                const eventCard = document.createElement('div');
                eventCard.classList.add('event-card');

                const imgElement = document.createElement('img');
                imgElement.src = `http://localhost:8000/api/uploads/${event.image}`; 
                imgElement.alt = event.title;

                const titleElement = document.createElement('h3');
                titleElement.textContent = event.title;

                const timeElement = document.createElement('p');
                timeElement.textContent = `Time: ${new Date(event.time).toLocaleString()}`; 
                const descriptionElement = document.createElement('p');
                descriptionElement.textContent = event.description;

                eventCard.appendChild(imgElement);
                eventCard.appendChild(titleElement);
                eventCard.appendChild(timeElement);
                eventCard.appendChild(descriptionElement);

                eventList.appendChild(eventCard);
            });
        })
        .catch(error => {
            console.error('Error fetching events:', error);
        });
});

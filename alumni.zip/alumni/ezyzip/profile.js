document.addEventListener('DOMContentLoaded', function () {
    const fullNameInput = document.getElementById('fullName');
    const registerNoInput = document.getElementById('registerNo');
    const departmentInput = document.getElementById('department');
    const passoutYearInput = document.getElementById('passoutYear');
    const mobileNumberInput = document.getElementById('mobileNumber');
    const emailInput = document.getElementById('email');
    const companyInput = document.getElementById('company');
    const locationInput = document.getElementById('location');
    const linkedinUrlInput = document.getElementById('linkedinUrl');
    const alumniImage = document.getElementById('alumniImage');
    const updateButton = document.getElementById('updateButton');
    const currentPassword = document.getElementById('current-password');
    const saveButton = document.getElementById('saveButton');
    const togglePassword = document.getElementById('togglePassword');

    let isEditMode = false;

    // Toggle Password Visibility
    togglePassword.addEventListener('click', function () {
        if (currentPassword.type === 'password') {
            currentPassword.type = 'text';
            togglePassword.textContent = 'visibility'; // Show icon for visibility
        } else {
            currentPassword.type = 'password';
            togglePassword.textContent = 'visibility_off'; // Show icon for hidden password
        }
    });

    // Fetch user profile data when the page loads
    async function fetchUserProfile() {
        try {
            const response = await fetch('http://localhost:8000/api/me', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch user profile');
            }

            const user = await response.json();

            // Populate the form fields with user data
            fullNameInput.value = user.username;
            registerNoInput.value = user.registerNumber;
            departmentInput.value = user.department;
            passoutYearInput.value = user.passoutYear;
            mobileNumberInput.value = user.mobileNumber;
            emailInput.value = user.email;
            companyInput.value = user.company;
            locationInput.value = user.location;
            linkedinUrlInput.value = user.linkedinUrl;
            alumniImage.src = user.image || './profile.png'; // Default image

            // Optionally, you can display samplePass for user reference
            currentPassword.value = user.samplePass; // Show as reference, but leave blank for security
        } catch (error) {
            console.error('Error fetching user profile:', error);
        }
    }

    function toggleEditMode() {
        isEditMode = !isEditMode;

        // Toggle input fields between read-only and editable
        fullNameInput.readOnly = !isEditMode;
        mobileNumberInput.readOnly = !isEditMode;
        emailInput.readOnly = !isEditMode;
        companyInput.readOnly = !isEditMode;
        locationInput.readOnly = !isEditMode;
        linkedinUrlInput.readOnly = !isEditMode;

        // Toggle button visibility
        updateButton.style.display = isEditMode ? 'none' : 'block';
        saveButton.style.display = isEditMode ? 'block' : 'none';
    }

    updateButton.addEventListener('click', function () {
        toggleEditMode();
    });

    saveButton.addEventListener('click', async function () {
        const updatedUserData = {
            username: fullNameInput.value,
            mobileNumber: mobileNumberInput.value,
            email: emailInput.value,
            company: companyInput.value,
            location: locationInput.value,
            linkedinUrl: linkedinUrlInput.value,
            password: currentPassword.value,  // Sending current password (as plain text in this case)
            samplePass: currentPassword.value // Keep samplePass updated too
        };

        try {
            const response = await fetch('http://localhost:8000/api/me', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(updatedUserData)
            });

            if (response.ok) {
                alert('Profile updated successfully');
                toggleEditMode();  // Disable edit mode after successful save
                fetchUserProfile(); // Fetch updated profile data
            } else {
                throw new Error('Failed to update profile');
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            alert('Error updating profile. Please try again.');
        }
    });

    // Initial fetch of the user profile when the page loads
    fetchUserProfile();
});

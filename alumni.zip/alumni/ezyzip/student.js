// Sample URL for the alumni data API
const apiUrl = 'http://localhost:8000/api/allAlumni'; // Replace with your actual API URL

document.addEventListener('DOMContentLoaded', () => {
    const filterYearInput = document.getElementById('filter-year');
    const filterDepartmentInput = document.getElementById('filter-department');
    const filterCompanyInput = document.getElementById('filter-company');
    const filterButton = document.getElementById('filter-btn');
    const alumniTableBody = document.getElementById('alumni-table-body');

    // Fetch alumni data when the page loads
    fetchAlumniData();

    // Fetch alumni data from the API
    function fetchAlumniData() {
        fetch(apiUrl, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
            }
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                populateAlumniTable(data);
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    }

    // Populate the alumni table with data
    function populateAlumniTable(alumni) {
        alumniTableBody.innerHTML = ''; // Clear existing rows
        alumni.forEach(alumnus => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${alumnus.username}</td>
                <td>${alumnus.registerNo}</td>
                <td>${alumnus.department}</td>
                <td>${alumnus.passoutYear}</td>
                <td>${alumnus.mobileNumber}</td>
                <td>${alumnus.email}</td>
                <td>${alumnus.company}</td>
                <td>${alumnus.location}</td>
                <td><a href="${alumnus.linkedinUrl}" target="_blank">LinkedIn</a></td>
            `;
            alumniTableBody.appendChild(row);
        });
    }

    // Filter the alumni based on user inputs
    filterButton.addEventListener('click', () => {
        const yearFilter = filterYearInput.value.trim().toLowerCase();
        const departmentFilter = filterDepartmentInput.value.trim().toLowerCase();
        const companyFilter = filterCompanyInput.value.trim().toLowerCase();

        fetch(apiUrl, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
            }
        })
            .then(response => response.json())
            .then(data => {
                const filteredAlumni = data.filter(alumnus => {
                    const passoutYear = alumnus.passoutYear ? alumnus.passoutYear.toString().toLowerCase() : '';
                    const department = alumnus.department ? alumnus.department.toLowerCase() : '';
                    const company = alumnus.company ? alumnus.company.toLowerCase() : '';

                    return (yearFilter === '' || passoutYear.includes(yearFilter)) &&
                           (departmentFilter === '' || department.includes(departmentFilter)) &&
                           (companyFilter === '' || company.includes(companyFilter));
                });
                populateAlumniTable(filteredAlumni);
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    });
});

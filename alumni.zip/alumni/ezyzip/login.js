document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("login-form");

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault(); // Prevent default form submission

        const email = loginForm.email.value;
        const password = loginForm.password.value;

        try {
            const response = await fetch('http://localhost:8000/api/login', { // Update the URL to match your backend
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                // Store token or cookies as needed
                localStorage.setItem('token', data.token);
                
                // Set the token as a cookie
                document.cookie = `token=${data.token}; path=/`; 
                console.log(document.cookie);
                // Redirect based on role
                switch(data.user.role) {
                    case "admin":
                        window.location.href = "/ezyzip/admin.html"; // Redirect to admin page
                        break;
                    case "alumni":
                        window.location.href = "/ezyzip/profile.html"; // Redirect to alumni page
                        break;
                    case "user":
                        window.location.href = "/ezyzip/student.html"; // Redirect to student page
                        break;
                    default:
                        alert('Role not recognized');
                }
            } else {
                alert(data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred during login');
        }
    });
});

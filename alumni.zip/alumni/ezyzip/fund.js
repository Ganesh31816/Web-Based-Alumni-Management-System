// Replace with your actual Stripe publishable key
const stripe = Stripe('YOUR_STRIPE_PUBLISHABLE_KEY');
const elements = stripe.elements();
const cardElement = elements.create('card');
cardElement.mount('#card-element');

document.getElementById('donation-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const amount = document.getElementById('amount').value;

    // Create a payment method
    const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
    });

    if (error) {
        document.getElementById('card-errors').textContent = error.message;
    } else {
        processDonation(paymentMethod.id, amount);
    }
});

// Function to process donation
async function processDonation(paymentMethodId, amount) {
    try {
        const response = await fetch('http://localhost:8000/donate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ paymentMethodId, amount }),
        });
        const data = await response.json();
        if (data.error) {
            document.getElementById('card-errors').textContent = data.error;
        } else {
            alert('Thank you for your donation!');
            document.getElementById('donation-form').reset();
        }
    } catch (error) {
        document.getElementById('card-errors').textContent = 'An error occurred.';
    }
}

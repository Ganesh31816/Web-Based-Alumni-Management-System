document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.querySelector('form');
    const usernameInput = registrationForm.querySelector('input[name="fullname"]');
    const emailInput = registrationForm.querySelector('input[name="email"]');
    const passwordInput = registrationForm.querySelector('input[name="password"]');
    const repeatPasswordInput = registrationForm.querySelector('input[name="repeat_password"]');

    registrationForm.addEventListener('submit', async (e) => {
        e.preventDefault();  

        // Get the values from the input fields
        const username = usernameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const repeatPassword = repeatPasswordInput.value.trim();

        // Basic validation
        if (!username || !email || !password || !repeatPassword) {
            alert('Please fill in all fields.');
            return;
        }

        if (password !== repeatPassword) {
            alert('Passwords do not match.');
            return;
        }

        // Create a user object to send to the backend
        const user = {
            username,
            email,
            password,
        };

        try {
            // Send a POST request to the backend API
            const response = await fetch('http://localhost:8000/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(user),
            });

            const result = await response.json();

            if (response.ok) {
                // Successful registration
                alert(result.message);
                // Redirect to login or another page if needed
                window.location.href = 'Login.html';
            } else {
                // Handle errors from the server
                alert(result.message || 'Registration failed. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Server error. Please try again later.');
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const addAlumniBtn = document.getElementById("add-alumni-btn");
    const alumniForm = document.getElementById("alumni-form");
    const cancelAlumniBtn = document.getElementById("cancel-alumni-btn");
    const submitAlumniBtn = document.getElementById("submit-alumni-btn");
    const alumniList = document.getElementById("alumni-list");

    const filterName = document.getElementById("filter-name");
    const filterDepartment = document.getElementById("filter-department");
    const filterYear = document.getElementById("filter-year");

    addAlumniBtn.addEventListener("click", () => {
        alumniForm.classList.toggle("hidden");
    });

    cancelAlumniBtn.addEventListener("click", () => {
        alumniForm.classList.add("hidden");
        clearAlumniForm();
    });

    submitAlumniBtn.addEventListener("click", async () => {
        const alumniData = getAlumniFormData();
        
        try {
            const response = await fetch("/api/alumni", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(alumniData),
            });
            if (response.ok) {
                const newAlumni = await response.json();
                addAlumniToList(newAlumni);
                alumniForm.classList.add("hidden");
                clearAlumniForm();
            } else {
                console.error("Error adding alumni:", response.statusText);
            }
        } catch (error) {
            console.error("Error adding alumni:", error);
        }
    });

    // Filter Alumni
    filterName.addEventListener("input", filterAlumni);
    filterDepartment.addEventListener("input", filterAlumni);
    filterYear.addEventListener("input", filterAlumni);

    function filterAlumni() {
        const nameValue = filterName.value.toLowerCase();
        const departmentValue = filterDepartment.value.toLowerCase();
        const yearValue = filterYear.value.toLowerCase();

        const alumniPosts = document.querySelectorAll(".alumni-post");
        alumniPosts.forEach(post => {
            const name = post.querySelector("h5").innerText.toLowerCase();
            const department = post.querySelector("p:nth-of-type(3)").innerText.toLowerCase();
            const year = post.querySelector("p:nth-of-type(4)").innerText.toLowerCase();

            const matchesName = name.includes(nameValue);
            const matchesDepartment = department.includes(departmentValue);
            const matchesYear = year.includes(yearValue);

            post.style.display = (matchesName && matchesDepartment && matchesYear) ? "block" : "none";
        });
    }

    function clearAlumniForm() {
        document.getElementById("alumni-name").value = "";
        document.getElementById("alumni-register").value = "";
        document.getElementById("alumni-department").value = "";
        document.getElementById("alumni-year").value = "";
        document.getElementById("alumni-mobile").value = "";
        document.getElementById("alumni-email").value = "";
        document.getElementById("alumni-company").value = "";
        document.getElementById("alumni-location").value = "";
        document.getElementById("alumni-linkedin").value = "";
    }

    function getAlumniFormData() {
        return {
            name: document.getElementById("alumni-name").value,
            register: document.getElementById("alumni-register").value,
            department: document.getElementById("alumni-department").value,
            year: document.getElementById("alumni-year").value,
            mobile: document.getElementById("alumni-mobile").value,
            email: document.getElementById("alumni-email").value,
            company: document.getElementById("alumni-company").value,
            location: document.getElementById("alumni-location").value,
            linkedin: document.getElementById("alumni-linkedin").value,
        };
    }

    function addAlumniToList(alumni) {
        const alumniPost = document.createElement("div");
        alumniPost.classList.add("alumni-post");
        
        alumniPost.innerHTML = `
            <h5>${alumni.name}</h5>
            <p>Register No: ${alumni.register}</p>
            <p>Department: ${alumni.department}</p>
            <p>Passout Year: ${alumni.year}</p>
            <p>Mobile No: ${alumni.mobile}</p>
            <p>Email: ${alumni.email}</p>
            <p>Current Company: ${alumni.company}</p>
            <p>Location: ${alumni.location}</p>
            <p>LinkedIn: <a href="${alumni.linkedin}" target="_blank">${alumni.linkedin}</a></p>
            <button class="edit-alumni-btn">Edit</button>
            <button class="delete-alumni-btn">Delete</button>
        `;

        alumniList.appendChild(alumniPost);

        alumniPost.querySelector(".delete-alumni-btn").addEventListener("click", () => {
            deleteAlumni(alumni.id, alumniPost);
        });

        alumniPost.querySelector(".edit-alumni-btn").addEventListener("click", () => {
            fillAlumniForm(alumni);
        });
    }

    function fillAlumniForm(alumni) {
        document.getElementById("alumni-name").value = alumni.name;
        document.getElementById("alumni-register").value = alumni.register;
        document.getElementById("alumni-department").value = alumni.department;
        document.getElementById("alumni-year").value = alumni.year;
        document.getElementById("alumni-mobile").value = alumni.mobile;
        document.getElementById("alumni-email").value = alumni.email;
        document.getElementById("alumni-company").value = alumni.company;
        document.getElementById("alumni-location").value = alumni.location;
        document.getElementById("alumni-linkedin").value = alumni.linkedin;

        alumniForm.classList.remove("hidden");
    }

    async function deleteAlumni(alumniId, alumniPost) {
        try {
            const response = await fetch(`/api/alumni/${alumniId}`, {
                method: "DELETE",
            });
            if (response.ok) {
                alumniPost.remove();
            } else {
                console.error("Error deleting alumni:", response.statusText);
            }
        } catch (error) {
            console.error("Error deleting alumni:", error);
        }
    }

    const addEventBtn = document.getElementById("add-event-btn");
    const eventForm = document.getElementById("event-form");
    const cancelEventBtn = document.getElementById("cancel-event-btn");
    const submitEventBtn = document.getElementById("submit-event-btn");
    const eventList = document.getElementById("event-list");

    addEventBtn.addEventListener("click", () => {
        eventForm.classList.toggle("hidden");
    });

    cancelEventBtn.addEventListener("click", () => {
        eventForm.classList.add("hidden");
        clearEventForm();
    });

    submitEventBtn.addEventListener("click", async () => {
        const eventData = getEventFormData();

        try {
            const response = await fetch("/api/events", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(eventData),
            });
            if (response.ok) {
                const newEvent = await response.json();
                addEventToList(newEvent);
                eventForm.classList.add("hidden");
                clearEventForm();
            } else {
                console.error("Error adding event:", response.statusText);
            }
        } catch (error) {
            console.error("Error adding event:", error);
        }
    });

    function clearEventForm() {
        document.getElementById("event-title").value = "";
        document.getElementById("event-time").value = "";
        document.getElementById("event-description").value = "";
        document.getElementById("event-image").value = "";
    }

    function getEventFormData() {
        return {
            title: document.getElementById("event-title").value,
            time: document.getElementById("event-time").value,
            description: document.getElementById("event-description").value,
            image: document.getElementById("event-image").files[0], // Handle image
        };
    }

    function addEventToList(event) {
        const eventPost = document.createElement("div");
        eventPost.classList.add("event-post");

        eventPost.innerHTML = `
            <h5>${event.title}</h5>
            <p>Time: ${event.time}</p>
            <p>Description: ${event.description}</p>
            <img src="${event.image}" alt="${event.title}" />
            <button class="edit-event-btn">Edit</button>
            <button class="delete-event-btn">Delete</button>
        `;

        eventList.appendChild(eventPost);

        eventPost.querySelector(".delete-event-btn").addEventListener("click", () => {
            deleteEvent(event.id, eventPost);
        });

        eventPost.querySelector(".edit-event-btn").addEventListener("click", () => {
            fillEventForm(event);
        });
    }

    function fillEventForm(event) {
        document.getElementById("event-title").value = event.title;
        document.getElementById("event-time").value = event.time;
        document.getElementById("event-description").value = event.description;
        document.getElementById("event-image").value = ""; // reset image field

        eventForm.classList.remove("hidden");
    }

    async function deleteEvent(eventId, eventPost) {
        try {
            const response = await fetch(`/api/events/${eventId}`, {
                method: "DELETE",
            });
            if (response.ok) {
                eventPost.remove();
            } else {
                console.error("Error deleting event:", response.statusText);
            }
        } catch (error) {
            console.error("Error deleting event:", error);
        }
    }
});

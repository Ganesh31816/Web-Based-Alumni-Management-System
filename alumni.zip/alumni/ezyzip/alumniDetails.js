document.addEventListener("DOMContentLoaded", function () {
    const alumniTableBody = document.getElementById("alumni-table-body");
    const alumniFormPopup = document.getElementById("alumni-form-popup");
    const addAlumniBtn = document.getElementById("add-alumni-btn");
    const cancelAlumniBtn = document.getElementById("cancel-alumni-btn");
    const alumniForm = document.getElementById("alumni-form");
    const filterYearInput = document.getElementById("filter-year");
    const filterDepartmentInput = document.getElementById("filter-department");
    const filterCompanyInput = document.getElementById("filter-company");
    const filterBtn = document.getElementById("filter-btn");

    let alumniList = [];
    let editMode = false;
    let editAlumniId = null;

    async function fetchAlumniData() {
        try {
            const response = await fetch('http://localhost:8000/api/alumni', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}` // Assuming JWT token is stored in localStorage
                }
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            alumniList = await response.json();
            renderAlumniTable(alumniList);
        } catch (error) {
            console.error("Error fetching alumni data:", error);
        }
    }

    function renderAlumniTable(data) {
        alumniTableBody.innerHTML = "";
        data.forEach(alumni => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${alumni.username}</td>
                <td>${alumni.registerNumber}</td>
                <td>${alumni.department}</td>
                <td>${alumni.passoutYear}</td>
                <td>${alumni.mobileNumber}</td>
                <td>${alumni.email}</td>
                <td>${alumni.company}</td>
                <td>${alumni.location}</td>
                <td><a href="${alumni.linkedinUrl}" target="_blank">LinkedIn</a></td>
                <td>
                    <button class="edit-btn" data-id="${alumni._id}">Edit</button>
                    <button class="delete-btn" data-id="${alumni._id}">Delete</button>
                </td>
            `;
            alumniTableBody.appendChild(row);
        });

        document.querySelectorAll(".edit-btn").forEach(btn => {
            btn.addEventListener("click", handleEditAlumni);
        });
        document.querySelectorAll(".delete-btn").forEach(btn => {
            btn.addEventListener("click", handleDeleteAlumni);
        });
    }

    function showAlumniForm() {
        alumniFormPopup.style.display = "block";
    }

    function hideAlumniForm() {
        alumniFormPopup.style.display = "none";
        alumniForm.reset();
        editMode = false;
        editAlumniId = null;
    }

    addAlumniBtn.addEventListener("click", function () {
        showAlumniForm();
    });

    cancelAlumniBtn.addEventListener("click", function () {
        hideAlumniForm();
    });

    alumniForm.addEventListener("submit", async function (event) {
        event.preventDefault();
        const alumniData = {
            username: document.getElementById("username").value,
            registerNumber: document.getElementById("register-number").value,
            department: document.getElementById("department").value,
            passoutYear: document.getElementById("passout-year").value,
            mobileNumber: document.getElementById("mobile-number").value,
            email: document.getElementById("email").value,
            company: document.getElementById("company").value,
            location: document.getElementById("location").value,
            linkedinUrl: document.getElementById("linkedin-url").value
        };

        if (editMode) {
            await updateAlumni(editAlumniId, alumniData);
        } else {
            await addAlumni(alumniData);
        }
    });

    async function addAlumni(alumniData) {
        try {
            console.log(alumniData)
            const response = await fetch('http://localhost:8000/api/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}` 
                },
                body: JSON.stringify(alumniData)
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const newAlumni = await response.json();
            alumniList.push(newAlumni);
            renderAlumniTable(alumniList);
            hideAlumniForm();
        } catch (error) {
            console.error("Error adding alumni:", error);
        }
    }

    function handleEditAlumni(event) {
        const alumniId = event.target.dataset.id;
        const alumni = alumniList.find(al => al._id === alumniId);
        if (alumni) {
            document.getElementById("username").value = alumni.username;
            document.getElementById("register-number").value = alumni.registerNumber;
            document.getElementById("department").value = alumni.department;
            document.getElementById("passout-year").value = alumni.passoutYear;
            document.getElementById("mobile-number").value = alumni.mobileNumber;
            document.getElementById("email").value = alumni.email;
            document.getElementById("company").value = alumni.company;
            document.getElementById("location").value = alumni.location;
            document.getElementById("linkedin-url").value = alumni.linkedinUrl;
            editMode = true;
            editAlumniId = alumniId;
            showAlumniForm();
        }
    }

    async function updateAlumni(alumniId, alumniData) {
        try {
            const response = await fetch(`http://localhost:8000/api/update/${alumniId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}` 
                },
                body: JSON.stringify(alumniData)
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const updatedAlumni = await response.json();
            alumniList = alumniList.map(alumni => alumni._id === alumniId ? updatedAlumni : alumni);
            renderAlumniTable(alumniList);
            hideAlumniForm();
        } catch (error) {
            console.error("Error updating alumni:", error);
        }
    }

    async function handleDeleteAlumni(event) {
        const alumniId = event.target.dataset.id;
        const confirmed = confirm("Are you sure you want to delete this alumni?");
        if (confirmed) {
            try {
                const response = await fetch(`http://localhost:8000/api/delete/${alumniId}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                alumniList = alumniList.filter(alumni => alumni._id !== alumniId);
                renderAlumniTable(alumniList);
            } catch (error) {
                console.error("Error deleting alumni:", error);
            }
        }
    }

    filterBtn.addEventListener("click", function () {
        const filteredAlumni = alumniList.filter(alumni => {
            return (
                (filterYearInput.value === "" || alumni.passoutYear.toString() === filterYearInput.value) &&
                (filterDepartmentInput.value === "" || alumni.department.toLowerCase().includes(filterDepartmentInput.value.toLowerCase())) &&
                (filterCompanyInput.value === "" || alumni.company.toLowerCase().includes(filterCompanyInput.value.toLowerCase()))
            );
        });
    
        if (filteredAlumni.length >0) {
            renderAlumniTable(filteredAlumni);
        } else {
            alumniTableBody.innerHTML = `
                <tr>
                    <td colspan="10" style="text-align:center;">No match found</td>
                </tr>
            `;
        }
    });
    

    fetchAlumniData();
}); 
